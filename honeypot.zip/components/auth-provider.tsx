"use client"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"

// Create auth context
const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  // Check if user is logged in
  useEffect(() => {
    const checkAuth = () => {
      try {
        const userData = localStorage.getItem("honeypot_user")
        if (userData) {
          setUser(JSON.parse(userData))
        } else if (pathname !== "/login" && !pathname.startsWith("/_next") && pathname !== "/") {
          // Only redirect to login if not on the home page, login page, or Next.js internal pages
          router.push("/login")
        }
      } catch (error) {
        console.error("Auth error:", error)
      } finally {
        setLoading(false)
      }
    }

    checkAuth()

    // Add event listener for storage changes to handle login/logout in other tabs
    const handleStorageChange = (e) => {
      if (e.key === "honeypot_user") {
        checkAuth()
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [pathname]) // Only re-run when pathname changes

  // Logout function
  const logout = () => {
    localStorage.removeItem("honeypot_user")
    setUser(null)
    router.push("/login")
  }

  // Check if user has required role
  const hasRole = (requiredRole) => {
    if (!user) return false
    if (requiredRole === "admin") return user.role === "admin"
    return true // "user" role or no specific role required
  }

  const value = {
    user,
    loading,
    logout,
    hasRole,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
