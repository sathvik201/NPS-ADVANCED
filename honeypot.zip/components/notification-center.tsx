"use client"

import { useState, useEffect } from "react"
import { AlertTriangle, Shield, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"

// Generate random notifications
const generateNotifications = () => {
  const notificationTypes = [
    {
      id: 1,
      title: "Brute Force Attack Detected",
      description: "Multiple failed login attempts from IP 192.168.1.45",
      time: "5 minutes ago",
      type: "critical",
    },
    {
      id: 2,
      title: "SQL Injection Attempt",
      description: "Malicious SQL query detected from IP 192.168.1.78",
      time: "15 minutes ago",
      type: "critical",
    },
    {
      id: 3,
      title: "Port Scan Detected",
      description: "Scanning activity from IP 192.168.1.102",
      time: "30 minutes ago",
      type: "warning",
    },
    {
      id: 4,
      title: "Honeypot Connection",
      description: "New connection to honeypot service",
      time: "1 hour ago",
      type: "info",
    },
    {
      id: 5,
      title: "System Update Available",
      description: "New security patches available for installation",
      time: "2 hours ago",
      type: "info",
    },
  ]

  return notificationTypes
}

export function NotificationCenter({ onClearAll }) {
  const [notifications, setNotifications] = useState([])
  const { toast } = useToast()

  useEffect(() => {
    setNotifications(generateNotifications())

    // Simulate receiving a new notification every 30 seconds
    const interval = setInterval(() => {
      const newNotification = {
        id: Date.now(),
        title: "New Attack Detected",
        description: `Suspicious activity from IP 192.168.1.${Math.floor(Math.random() * 255)}`,
        time: "Just now",
        type: "critical",
      }

      setNotifications((prev) => [newNotification, ...prev])

      // Show toast notification
      toast({
        title: "Security Alert",
        description: newNotification.description,
        variant: "destructive",
      })
    }, 30000)

    return () => clearInterval(interval)
  }, [toast])

  const dismissNotification = (id) => {
    setNotifications(notifications.filter((notification) => notification.id !== id))
  }

  const getNotificationIcon = (type) => {
    switch (type) {
      case "critical":
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "info":
        return <Shield className="h-5 w-5 text-blue-500" />
      default:
        return <Shield className="h-5 w-5 text-emerald-500" />
    }
  }

  const getNotificationColor = (type) => {
    switch (type) {
      case "critical":
        return "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800"
      case "warning":
        return "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800"
      case "info":
        return "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800"
      default:
        return "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800"
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between py-2">
        <h2 className="text-lg font-semibold">Notifications</h2>
        <Button variant="ghost" size="sm" onClick={onClearAll}>
          Clear all
        </Button>
      </div>
      <Separator />
      {notifications.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full py-8">
          <Shield className="h-12 w-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium mb-1">No notifications</h3>
          <p className="text-sm text-muted-foreground text-center">You're all caught up! No new security alerts.</p>
        </div>
      ) : (
        <ScrollArea className="flex-1 py-4">
          <div className="space-y-4 pr-4">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`relative p-4 rounded-lg border ${getNotificationColor(notification.type)}`}
              >
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 h-6 w-6"
                  onClick={() => dismissNotification(notification.id)}
                >
                  <X className="h-3 w-3" />
                  <span className="sr-only">Dismiss</span>
                </Button>
                <div className="flex gap-3">
                  {getNotificationIcon(notification.type)}
                  <div>
                    <h3 className="font-medium text-sm">{notification.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{notification.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">{notification.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  )
}
