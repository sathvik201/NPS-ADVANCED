"use client"

import { useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowRight, Bell, Lock, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  const router = useRouter()

  useEffect(() => {
    // Check if user is already logged in
    const userData = localStorage.getItem("honeypot_user")
    if (userData) {
      // If already logged in, redirect to dashboard
      router.push("/dashboard")
    }
  }, [router])

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-emerald-500" />
            <h1 className="text-3xl font-bold">SecureHoney</h1>
          </div>
          <Button asChild variant="outline">
            <Link href="/login">Login</Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="space-y-4">
            <h2 className="text-4xl font-bold tracking-tight">Advanced Honeypot Security Monitoring</h2>
            <p className="text-xl text-muted-foreground">
              Detect, analyze, and respond to potential threats with our comprehensive honeypot solution.
            </p>
            <div className="flex gap-4 pt-4">
              <Button asChild size="lg">
                <Link href="/login">
                  Get Started <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/login">View Demo</Link>
              </Button>
            </div>
          </div>
          <div className="rounded-xl overflow-hidden shadow-lg border bg-card">
            <div className="aspect-video bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 flex items-center justify-center p-8">
              <div className="relative">
                <div className="absolute inset-0 border-8 border-dashed border-emerald-500/30 rounded-full animate-[spin_20s_linear_infinite]"></div>
                <div className="bg-card p-6 rounded-full shadow-lg flex items-center justify-center">
                  <Shield className="h-16 w-16 text-emerald-500" />
                </div>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">Active Protection</h3>
              <p className="text-muted-foreground">
                Our honeypot system actively monitors for suspicious activities and potential threats in real-time.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardHeader>
              <div className="rounded-full w-12 h-12 bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center mb-4">
                <Bell className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <CardTitle>Real-time Alerts</CardTitle>
              <CardDescription>Get instant notifications when suspicious activity is detected</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Our system monitors connection attempts and alerts you immediately when potential threats are
                identified.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/login">
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <div className="rounded-full w-12 h-12 bg-blue-100 dark:bg-blue-900 flex items-center justify-center mb-4">
                <Lock className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle>Advanced Security</CardTitle>
              <CardDescription>Enterprise-grade protection for your network</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Our honeypot creates decoy systems that attract attackers away from your valuable assets while gathering
                intelligence.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/login">
                  Configure <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <div className="rounded-full w-12 h-12 bg-purple-100 dark:bg-purple-900 flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle>Threat Intelligence</CardTitle>
              <CardDescription>Comprehensive analytics and reporting</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Gain valuable insights into attack patterns and techniques with detailed logs and analytics.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/login">
                  View logs <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
