"use client"

import { useState, useEffect } from "react"
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Globe,
  RefreshCw,
  Shield,
  CreditCard,
  Zap,
  TrendingUp,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { Progress } from "@/components/ui/progress"

// Generate real-time today's data
const generateTodayData = () => {
  const now = new Date()
  const currentHour = now.getHours()
  const data = []

  for (let hour = 0; hour <= currentHour; hour++) {
    const baseActivity = Math.floor(Math.random() * 15) + 5
    const peakMultiplier = hour >= 9 && hour <= 17 ? 1.5 : 1 // Business hours peak
    const value = Math.floor(baseActivity * peakMultiplier)

    data.push({
      hour: hour.toString().padStart(2, "0") + ":00",
      value,
      timestamp: new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour).getTime(),
    })
  }

  return data
}

// Generate global attack data with realistic world coordinates
const generateGlobalAttacks = () => {
  const attackSources = [
    { name: "United States", attacks: Math.floor(Math.random() * 100) + 50, x: 20, y: 40, country: "US" },
    { name: "Canada", attacks: Math.floor(Math.random() * 60) + 30, x: 18, y: 25, country: "CA" },
    { name: "Brazil", attacks: Math.floor(Math.random() * 70) + 35, x: 30, y: 70, country: "BR" },
    { name: "United Kingdom", attacks: Math.floor(Math.random() * 80) + 40, x: 48, y: 30, country: "GB" },
    { name: "Germany", attacks: Math.floor(Math.random() * 75) + 45, x: 52, y: 32, country: "DE" },
    { name: "France", attacks: Math.floor(Math.random() * 65) + 35, x: 50, y: 35, country: "FR" },
    { name: "Russia", attacks: Math.floor(Math.random() * 90) + 60, x: 70, y: 20, country: "RU" },
    { name: "China", attacks: Math.floor(Math.random() * 95) + 65, x: 75, y: 40, country: "CN" },
    { name: "Japan", attacks: Math.floor(Math.random() * 55) + 35, x: 82, y: 42, country: "JP" },
    { name: "South Korea", attacks: Math.floor(Math.random() * 50) + 30, x: 80, y: 44, country: "KR" },
    { name: "India", attacks: Math.floor(Math.random() * 85) + 55, x: 68, y: 50, country: "IN" },
    { name: "Australia", attacks: Math.floor(Math.random() * 45) + 25, x: 82, y: 75, country: "AU" },
    { name: "South Africa", attacks: Math.floor(Math.random() * 40) + 20, x: 55, y: 75, country: "ZA" },
    { name: "Egypt", attacks: Math.floor(Math.random() * 35) + 20, x: 54, y: 45, country: "EG" },
    { name: "Nigeria", attacks: Math.floor(Math.random() * 30) + 15, x: 52, y: 55, country: "NG" },
  ]

  return attackSources.sort((a, b) => b.attacks - a.attacks)
}

// Generate random data for charts
const generateRandomData = () => {
  const weeklyActivity = [
    { name: "Mon", value: Math.floor(Math.random() * 20) + 15 },
    { name: "Tue", value: Math.floor(Math.random() * 25) + 20 },
    { name: "Wed", value: Math.floor(Math.random() * 30) + 25 },
    { name: "Thu", value: Math.floor(Math.random() * 35) + 30 },
    { name: "Fri", value: Math.floor(Math.random() * 25) + 20 },
    { name: "Sat", value: Math.floor(Math.random() * 15) + 10 },
    { name: "Sun", value: Math.floor(Math.random() * 10) + 5 },
  ]

  const baseValue = Math.floor(Math.random() * 20) + 30
  const monthlyThreat = [
    { name: "Jan", value: baseValue },
    { name: "Feb", value: baseValue + Math.floor(Math.random() * 10) },
    { name: "Mar", value: baseValue + Math.floor(Math.random() * 15) + 5 },
    { name: "Apr", value: baseValue + Math.floor(Math.random() * 20) + 10 },
    { name: "May", value: baseValue + Math.floor(Math.random() * 25) + 15 },
    { name: "Jun", value: baseValue + Math.floor(Math.random() * 30) + 20 },
  ]

  const attackTypes = [
    { name: "Brute Force", value: Math.floor(Math.random() * 40) + 30 },
    { name: "SQL Injection", value: Math.floor(Math.random() * 30) + 20 },
    { name: "XSS", value: Math.floor(Math.random() * 25) + 15 },
    { name: "Port Scan", value: Math.floor(Math.random() * 35) + 25 },
    { name: "DoS", value: Math.floor(Math.random() * 20) + 10 },
  ]

  return {
    weeklyActivity,
    monthlyThreat,
    attackTypes,
  }
}

export default function Dashboard() {
  const { user, hasRole } = useAuth()
  const { toast } = useToast()
  const [honeypotStatus, setHoneypotStatus] = useState("Active")
  const [detectedThreats, setDetectedThreats] = useState(Math.floor(Math.random() * 10) + 1)
  const [chartData, setChartData] = useState(generateRandomData())
  const [todayData, setTodayData] = useState(generateTodayData())
  const [globalAttacks, setGlobalAttacks] = useState(generateGlobalAttacks())
  const [realTimeEvents, setRealTimeEvents] = useState([])
  const [isUnderAttack, setIsUnderAttack] = useState(false)
  const [flashCount, setFlashCount] = useState(0)

  // Update today's data every 10 minutes
  useEffect(() => {
    const todayInterval = setInterval(
      () => {
        setTodayData(generateTodayData())
      },
      10 * 60 * 1000,
    ) // 10 minutes

    return () => clearInterval(todayInterval)
  }, [])

  // Real-time events every 5 minutes
  useEffect(() => {
    const eventInterval = setInterval(
      () => {
        const eventTypes = ["Brute Force", "SQL Injection", "Port Scan", "XSS Attack", "DoS Attack"]
        const regions = ["North America", "Europe", "Asia", "South America", "Africa", "Australia"]

        const newEvent = {
          id: Date.now(),
          type: eventTypes[Math.floor(Math.random() * eventTypes.length)],
          region: regions[Math.floor(Math.random() * regions.length)],
          ip: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
          timestamp: new Date(),
          severity: Math.random() > 0.7 ? "high" : Math.random() > 0.4 ? "medium" : "low",
        }

        // Check for big attack (high severity)
        if (newEvent.severity === "high" && Math.random() > 0.6) {
          triggerAttackFlash()
        }

        setRealTimeEvents((prev) => [newEvent, ...prev.slice(0, 9)])
        setGlobalAttacks(generateGlobalAttacks())
      },
      5 * 60 * 1000,
    ) // 5 minutes

    return () => clearInterval(eventInterval)
  }, [])

  // Attack flash effect
  const triggerAttackFlash = () => {
    setIsUnderAttack(true)
    setFlashCount(0)

    const flashInterval = setInterval(() => {
      setFlashCount((prev) => {
        if (prev >= 30) {
          // 30 flashes over 30 seconds (1 per second)
          clearInterval(flashInterval)
          setIsUnderAttack(false)
          return 0
        }
        return prev + 1
      })
    }, 1000) // Flash every second for 30 seconds
  }

  // Refresh data when page loads
  useEffect(() => {
    refreshData()

    // Simulate attack detection every 5 minutes with chance of big attack
    const attackInterval = setInterval(
      () => {
        const attackTypes = [
          "Brute Force Attack",
          "SQL Injection Attempt",
          "XSS Attack",
          "Port Scanning",
          "Command Injection",
        ]

        const randomAttack = attackTypes[Math.floor(Math.random() * attackTypes.length)]
        const randomIP = `192.168.1.${Math.floor(Math.random() * 255)}`
        const isBigAttack = Math.random() > 0.7

        if (isBigAttack) {
          triggerAttackFlash()
          toast({
            title: "🚨 CRITICAL ATTACK DETECTED!",
            description: `Major ${randomAttack} from IP ${randomIP}`,
            variant: "destructive",
          })
        } else {
          toast({
            title: "⚠️ Attack Detected",
            description: `${randomAttack} from IP ${randomIP}`,
            variant: "destructive",
          })
        }

        setDetectedThreats((prev) => prev + (isBigAttack ? 3 : 1))
      },
      5 * 60 * 1000, // Every 5 minutes
    )

    return () => clearInterval(attackInterval)
  }, [toast])

  const refreshData = () => {
    setHoneypotStatus(Math.random() > 0.2 ? "Active" : "Inactive")
    setDetectedThreats(Math.floor(Math.random() * 10) + 1)
    setChartData(generateRandomData())
    setTodayData(generateTodayData())
    setGlobalAttacks(generateGlobalAttacks())
  }

  // Recent alerts based on detected threats
  const generateRecentAlerts = () => {
    const alerts = []
    const alertTypes = [
      "Brute force attack detected",
      "SQL injection attempt",
      "Port scanning activity",
      "XSS attempt detected",
      "Suspicious login attempt",
      "Command injection attempt",
      "File inclusion attempt",
    ]

    for (let i = 0; i < Math.min(detectedThreats, 5); i++) {
      const randomAlert = alertTypes[Math.floor(Math.random() * alertTypes.length)]
      const randomTime = new Date(Date.now() - Math.floor(Math.random() * 86400000))

      alerts.push({
        id: i,
        type: randomAlert,
        time: randomTime,
        ip: `192.168.1.${Math.floor(Math.random() * 255)}`,
      })
    }

    return alerts.sort((a, b) => b.time - a.time)
  }

  const recentAlerts = generateRecentAlerts()

  return (
    <div
      className={`min-h-screen transition-colors duration-500 ${
        isUnderAttack && flashCount % 2 === 0
          ? "bg-gradient-to-b from-red-900 to-black"
          : "bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900"
      }`}
    >
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-2 mb-8">
          <h1 className={`text-3xl font-bold ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
            Security Dashboard
          </h1>
          {isUnderAttack && (
            <Badge variant="destructive" className="animate-pulse">
              🚨 UNDER ATTACK
            </Badge>
          )}
          {hasRole("admin") && (
            <Badge variant="outline" className="ml-2">
              Admin View
            </Badge>
          )}
          <div className="ml-auto flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link href="/pricing">
                <CreditCard className="h-4 w-4 mr-2" />
                Upgrade Plan
              </Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent" onClick={refreshData}>
              <RefreshCw className="h-4 w-4" />
              Refresh Data
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className={`text-sm font-medium ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                Honeypot Status
              </CardTitle>
              <Shield className="h-4 w-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div
                  className={`h-3 w-3 rounded-full ${
                    honeypotStatus === "Active"
                      ? isUnderAttack
                        ? "bg-red-500 animate-pulse"
                        : "bg-emerald-500 animate-pulse"
                      : "bg-red-500"
                  }`}
                ></div>
                <div className={`text-2xl font-bold ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                  {honeypotStatus}
                </div>
              </div>
              <p
                className={`text-xs mt-2 ${isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"}`}
              >
                Last updated: Just now
              </p>
            </CardContent>
          </Card>

          <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className={`text-sm font-medium ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                Live Threats
              </CardTitle>
              <AlertTriangle className={`h-4 w-4 ${isUnderAttack ? "text-red-400" : "text-amber-500"}`} />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className={`text-2xl font-bold ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                  {detectedThreats}
                </div>
                <Badge
                  variant={isUnderAttack ? "destructive" : "outline"}
                  className="text-xs font-normal animate-pulse"
                >
                  <Zap className="h-3 w-3 mr-1" />
                  {isUnderAttack ? "CRITICAL" : "LIVE"}
                </Badge>
              </div>
              <p
                className={`text-xs mt-2 ${isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"}`}
              >
                {detectedThreats > 5 ? "High alert level" : "Normal alert level"}
              </p>
            </CardContent>
          </Card>

          <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className={`text-sm font-medium ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                Global Sources
              </CardTitle>
              <Globe className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                {globalAttacks.length}
              </div>
              <p
                className={`text-xs mt-2 ${isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"}`}
              >
                Countries detected: {globalAttacks.filter((c) => c.attacks > 40).length} active
              </p>
            </CardContent>
          </Card>

          <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className={`text-sm font-medium ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                Today's Activity
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                {todayData.reduce((sum, item) => sum + item.value, 0)}
              </div>
              <p
                className={`text-xs mt-2 ${isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"}`}
              >
                Peak hour: {todayData.reduce((max, item) => (item.value > max.value ? item : max), todayData[0])?.hour}
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="realtime" className="space-y-6">
          <TabsList className="grid grid-cols-5 w-full max-w-2xl">
            <TabsTrigger value="realtime">Real-time</TabsTrigger>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="global">Global Map</TabsTrigger>
            <TabsTrigger value="threats">Threats</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
          </TabsList>

          <TabsContent value="realtime" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-blue-500" />
                    <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                      Today's Activity (Live)
                    </CardTitle>
                    <Badge variant="outline" className="text-xs animate-pulse">
                      <Zap className="h-3 w-3 mr-1" />
                      Updates every 10min
                    </Badge>
                  </div>
                  <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                    Real-time hourly attack attempts for today
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] relative">
                    <div className="absolute inset-0 flex items-end">
                      {todayData.map((hour, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center justify-end h-full px-1">
                          <div
                            className={`w-full rounded-t-sm transition-all duration-1000 relative group ${
                              isUnderAttack && flashCount % 2 === 0
                                ? "bg-gradient-to-t from-red-600 to-red-400"
                                : "bg-gradient-to-t from-blue-600 to-blue-400 animate-pulse"
                            }`}
                            style={{ height: `${Math.max(5, (hour.value / 25) * 100)}%` }}
                          >
                            <div className="absolute opacity-0 group-hover:opacity-100 bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 pointer-events-none transition-opacity">
                              {hour.value} attempts at {hour.hour}
                            </div>
                          </div>
                          <div
                            className={`text-xs mt-2 transform -rotate-45 origin-top-left ${
                              isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                            }`}
                          >
                            {hour.hour}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div
                    className={`mt-4 text-xs text-center ${
                      isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                    }`}
                  >
                    Total today: {todayData.reduce((sum, item) => sum + item.value, 0)} attempts
                    <span className="ml-2 text-emerald-500">● Updates every 10 minutes</span>
                  </div>
                </CardContent>
              </Card>

              <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                      Live Event Stream
                    </CardTitle>
                    <Badge variant="outline" className="text-xs animate-pulse">
                      <Zap className="h-3 w-3 mr-1" />
                      Every 5min
                    </Badge>
                  </div>
                  <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                    Security events detected every 5 minutes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-[250px] overflow-y-auto">
                    {realTimeEvents.length > 0 ? (
                      realTimeEvents.map((event) => (
                        <div
                          key={event.id}
                          className={`p-3 rounded-lg border transition-all duration-500 ${
                            isUnderAttack && flashCount % 2 === 0
                              ? "bg-red-800 border-red-600"
                              : event.severity === "high"
                                ? "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800"
                                : event.severity === "medium"
                                  ? "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800"
                                  : "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-2 h-2 rounded-full animate-pulse ${
                                  event.severity === "high"
                                    ? "bg-red-500"
                                    : event.severity === "medium"
                                      ? "bg-amber-500"
                                      : "bg-blue-500"
                                }`}
                              ></div>
                              <span
                                className={`font-medium text-sm ${
                                  isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""
                                }`}
                              >
                                {event.type}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {event.region}
                              </Badge>
                            </div>
                            <span
                              className={`text-xs ${
                                isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                              }`}
                            >
                              {event.timestamp.toLocaleTimeString()}
                            </span>
                          </div>
                          <p
                            className={`text-xs mt-1 ${
                              isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                            }`}
                          >
                            IP: {event.ip}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        <Activity className="h-8 w-8 text-muted-foreground/50 mb-2" />
                        <p className="text-sm text-muted-foreground">Waiting for events (every 5 minutes)...</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="global" className="space-y-6">
            <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-blue-500" />
                  <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                    Global Attack Network
                  </CardTitle>
                  <Badge variant="outline" className="text-xs animate-pulse">
                    <Zap className="h-3 w-3 mr-1" />
                    LIVE
                  </Badge>
                </div>
                <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                  Real-time global network visualization of attack sources
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    {/* World Map with Attack Visualization using your provided image */}
                    <div
                      className={`h-[500px] rounded-xl relative overflow-hidden border-2 ${
                        isUnderAttack && flashCount % 2 === 0
                          ? "border-red-500 shadow-red-500/20"
                          : "border-blue-500/30 shadow-blue-500/10"
                      } shadow-2xl`}
                      style={{
                        backgroundImage: `url('/images/world-map-3d.png')`,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        backgroundRepeat: "no-repeat",
                      }}
                    >
                      {/* Dark overlay for better contrast */}
                      <div
                        className={`absolute inset-0 ${
                          isUnderAttack && flashCount % 2 === 0
                            ? "bg-gradient-to-br from-red-900/60 via-red-800/40 to-black/60"
                            : "bg-gradient-to-br from-blue-900/60 via-blue-800/40 to-slate-900/60"
                        }`}
                      ></div>

                      {/* Tech grid overlay */}
                      <div
                        className="absolute inset-0 opacity-20"
                        style={{
                          backgroundImage: `
                    linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
                  `,
                          backgroundSize: "40px 40px",
                        }}
                      ></div>

                      {/* Connection Lines SVG Overlay */}
                      <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
                        <defs>
                          <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="rgba(59, 130, 246, 0.8)" />
                            <stop offset="50%" stopColor="rgba(147, 197, 253, 1)" />
                            <stop offset="100%" stopColor="rgba(59, 130, 246, 0.8)" />
                          </linearGradient>
                          <filter id="glow">
                            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                            <feMerge>
                              <feMergeNode in="coloredBlur" />
                              <feMergeNode in="SourceGraphic" />
                            </feMerge>
                          </filter>
                        </defs>

                        {/* Generate connection lines between major attack sources */}
                        {globalAttacks.slice(0, 8).map((source, i) => {
                          const nextSource = globalAttacks[(i + 1) % 8]
                          const x1 = (source.x / 100) * 500
                          const y1 = (source.y / 100) * 500
                          const x2 = (nextSource.x / 100) * 500
                          const y2 = (nextSource.y / 100) * 500
                          const midX = (x1 + x2) / 2
                          const midY = Math.min(y1, y2) - 30

                          return (
                            <path
                              key={`connection-${i}`}
                              d={`M ${x1} ${y1} Q ${midX} ${midY} ${x2} ${y2}`}
                              stroke="url(#connectionGradient)"
                              strokeWidth="2"
                              fill="none"
                              filter="url(#glow)"
                              className="animate-pulse"
                              strokeDasharray="8,4"
                              opacity="0.8"
                            >
                              <animate
                                attributeName="stroke-dashoffset"
                                values="0;12"
                                dur="3s"
                                repeatCount="indefinite"
                              />
                            </path>
                          )
                        })}
                      </svg>

                      {/* Attack Source Nodes */}
                      {globalAttacks.map((source, i) => (
                        <div
                          key={source.country}
                          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20"
                          style={{
                            left: `${source.x}%`,
                            top: `${source.y}%`,
                          }}
                        >
                          <div className="relative group cursor-pointer">
                            {/* Outer pulse ring */}
                            <div
                              className={`absolute inset-0 w-10 h-10 rounded-full animate-ping ${
                                source.attacks > 70
                                  ? "bg-red-400"
                                  : source.attacks > 50
                                    ? "bg-yellow-400"
                                    : "bg-blue-400"
                              }`}
                              style={{ animationDuration: "3s" }}
                            ></div>

                            {/* Middle glow ring */}
                            <div
                              className={`absolute inset-1 w-8 h-8 rounded-full ${
                                source.attacks > 70
                                  ? "bg-red-500/70 shadow-red-500/80"
                                  : source.attacks > 50
                                    ? "bg-yellow-500/70 shadow-yellow-500/80"
                                    : "bg-blue-500/70 shadow-blue-500/80"
                              } shadow-2xl animate-pulse`}
                              style={{ animationDuration: "2s" }}
                            ></div>

                            {/* Inner core */}
                            <div
                              className={`relative w-10 h-10 rounded-full flex items-center justify-center ${
                                source.attacks > 70
                                  ? "bg-red-500 shadow-red-500/90"
                                  : source.attacks > 50
                                    ? "bg-yellow-500 shadow-yellow-500/90"
                                    : "bg-blue-500 shadow-blue-500/90"
                              } shadow-2xl border-2 border-white/40 backdrop-blur-sm`}
                            >
                              <div className="w-3 h-3 bg-white rounded-full animate-pulse shadow-lg"></div>
                            </div>

                            {/* Enhanced Tooltip */}
                            <div className="absolute opacity-0 group-hover:opacity-100 bottom-full mb-4 left-1/2 transform -translate-x-1/2 transition-all duration-300 z-30">
                              <div className="bg-black/95 backdrop-blur-md text-white text-sm rounded-xl px-5 py-4 shadow-2xl border border-white/20 min-w-[200px]">
                                <div className="font-bold text-lg text-center mb-2">{source.name}</div>
                                <div className="space-y-1">
                                  <div className="flex justify-between">
                                    <span className="text-gray-300">Attacks:</span>
                                    <span className="font-bold">{source.attacks}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-300">Country:</span>
                                    <span className="font-mono text-sm">{source.country}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-300">Threat Level:</span>
                                    <span
                                      className={`font-bold text-sm ${
                                        source.attacks > 70
                                          ? "text-red-400"
                                          : source.attacks > 50
                                            ? "text-yellow-400"
                                            : "text-blue-400"
                                      }`}
                                    >
                                      {source.attacks > 70 ? "CRITICAL" : source.attacks > 50 ? "HIGH" : "MEDIUM"}
                                    </span>
                                  </div>
                                </div>
                                {/* Arrow */}
                                <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/95"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}

                      {/* Enhanced Legend */}
                      <div className="absolute bottom-6 left-6 bg-black/90 backdrop-blur-md rounded-xl p-6 text-white border border-white/20 shadow-2xl z-30">
                        <div className="font-bold text-xl mb-4 text-blue-300">Threat Levels</div>
                        <div className="space-y-4">
                          <div className="flex items-center gap-4">
                            <div className="relative">
                              <div className="w-5 h-5 bg-red-500 rounded-full shadow-red-500/80 shadow-xl"></div>
                              <div className="absolute inset-0 w-5 h-5 bg-red-400 rounded-full animate-ping"></div>
                            </div>
                            <span className="font-medium">Critical (70+ attacks)</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="relative">
                              <div className="w-5 h-5 bg-yellow-500 rounded-full shadow-yellow-500/80 shadow-xl"></div>
                              <div className="absolute inset-0 w-5 h-5 bg-yellow-400 rounded-full animate-ping"></div>
                            </div>
                            <span className="font-medium">High (50-70 attacks)</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="relative">
                              <div className="w-5 h-5 bg-blue-500 rounded-full shadow-blue-500/80 shadow-xl"></div>
                              <div className="absolute inset-0 w-5 h-5 bg-blue-400 rounded-full animate-ping"></div>
                            </div>
                            <span className="font-medium">Medium (&lt;50 attacks)</span>
                          </div>
                        </div>
                      </div>

                      {/* Network Status */}
                      <div className="absolute top-6 right-6 bg-black/90 backdrop-blur-md rounded-xl p-5 text-white border border-white/20 shadow-2xl z-30">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse shadow-green-400/80 shadow-xl"></div>
                          <span className="font-bold text-lg text-green-300">Network Online</span>
                        </div>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between gap-4">
                            <span className="text-gray-300">Active Nodes:</span>
                            <span className="font-bold">{globalAttacks.length}</span>
                          </div>
                          <div className="flex justify-between gap-4">
                            <span className="text-gray-300">Total Attacks:</span>
                            <span className="font-bold">
                              {globalAttacks.reduce((sum, source) => sum + source.attacks, 0)}
                            </span>
                          </div>
                          <div className="flex justify-between gap-4">
                            <span className="text-gray-300">Status:</span>
                            <span className="font-bold text-green-400">MONITORING</span>
                          </div>
                        </div>
                      </div>

                      {/* Scanning animation overlay */}
                      <div className="absolute inset-0 pointer-events-none z-10">
                        <div
                          className="absolute w-full h-1 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"
                          style={{
                            top: "25%",
                            animation: "scan 6s ease-in-out infinite",
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className={`font-bold text-xl ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                      Attack Sources
                    </h3>
                    <div className="space-y-3 max-h-[450px] overflow-y-auto pr-2">
                      {globalAttacks.slice(0, 15).map((source, i) => (
                        <div
                          key={source.country}
                          className={`flex items-center justify-between p-4 rounded-xl border transition-all duration-300 hover:scale-105 hover:shadow-xl ${
                            isUnderAttack && flashCount % 2 === 0
                              ? "bg-red-800/60 border-red-600 backdrop-blur-sm"
                              : "bg-card/90 backdrop-blur-sm hover:bg-card border-border hover:border-blue-300/50 hover:shadow-blue-500/20"
                          }`}
                        >
                          <div className="flex items-center gap-4">
                            <div
                              className={`text-xl font-bold w-8 text-center ${
                                isUnderAttack && flashCount % 2 === 0 ? "text-white" : "text-blue-500"
                              }`}
                            >
                              #{i + 1}
                            </div>
                            <div
                              className={`w-5 h-5 rounded-full ${
                                source.attacks > 70
                                  ? "bg-red-500 shadow-red-500/80"
                                  : source.attacks > 50
                                    ? "bg-yellow-500 shadow-yellow-500/80"
                                    : "bg-blue-500 shadow-blue-500/80"
                              } shadow-xl animate-pulse`}
                            ></div>
                            <div>
                              <div
                                className={`font-bold text-lg ${
                                  isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""
                                }`}
                              >
                                {source.name}
                              </div>
                              <div
                                className={`text-sm ${
                                  isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                                }`}
                              >
                                {source.country} •{" "}
                                <span
                                  className={`font-medium ${
                                    source.attacks > 70
                                      ? "text-red-400"
                                      : source.attacks > 50
                                        ? "text-yellow-400"
                                        : "text-blue-400"
                                  }`}
                                >
                                  {source.attacks > 70 ? "Critical" : source.attacks > 50 ? "High" : "Medium"}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div
                              className={`font-bold text-2xl ${
                                isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""
                              }`}
                            >
                              {source.attacks}
                            </div>
                            <div
                              className={`text-sm ${
                                isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                              }`}
                            >
                              attacks
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs remain the same but with flash effect styling */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-blue-500" />
                    <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                      Weekly Activity
                    </CardTitle>
                  </div>
                  <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                    Connection attempts detected by honeypot
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] relative">
                    <div className="absolute inset-0 flex items-end">
                      {chartData.weeklyActivity.map((day, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center justify-end h-full px-1">
                          <div
                            className={`w-full rounded-t-sm transition-all duration-500 relative group ${
                              isUnderAttack && flashCount % 2 === 0 ? "bg-red-500" : "bg-blue-500"
                            }`}
                            style={{ height: `${(day.value / 40) * 100}%` }}
                          >
                            <div className="absolute opacity-0 group-hover:opacity-100 bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 pointer-events-none transition-opacity">
                              {day.value} attempts
                            </div>
                          </div>
                          <div
                            className={`text-xs mt-2 ${
                              isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                            }`}
                          >
                            {day.name}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div
                      className={`absolute left-0 top-0 bottom-0 flex flex-col justify-between text-xs ${
                        isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                      }`}
                    >
                      <span>40</span>
                      <span>30</span>
                      <span>20</span>
                      <span>10</span>
                      <span>0</span>
                    </div>
                  </div>
                  <div
                    className={`mt-2 text-xs text-center ${
                      isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                    }`}
                  >
                    Total weekly attempts: {chartData.weeklyActivity.reduce((sum, item) => sum + item.value, 0)}
                  </div>
                </CardContent>
              </Card>

              <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                      Threat Trends
                    </CardTitle>
                  </div>
                  <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                    Six-month overview of detected threats
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] relative">
                    <div className="absolute inset-0 flex items-end">
                      {chartData.monthlyThreat.map((month, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center justify-end h-full px-1">
                          <div
                            className={`w-full rounded-t-sm transition-all duration-500 relative group ${
                              isUnderAttack && flashCount % 2 === 0
                                ? "bg-gradient-to-t from-red-600 to-red-400"
                                : "bg-gradient-to-t from-amber-600 to-amber-400"
                            }`}
                            style={{ height: `${(month.value / 80) * 100}%` }}
                          >
                            <div className="absolute opacity-0 group-hover:opacity-100 bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 pointer-events-none transition-opacity">
                              {month.value} threats
                            </div>
                          </div>
                          <div
                            className={`text-xs mt-2 ${
                              isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                            }`}
                          >
                            {month.name}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div
                      className={`absolute left-0 top-0 bottom-0 flex flex-col justify-between text-xs ${
                        isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                      }`}
                    >
                      <span>80</span>
                      <span>60</span>
                      <span>40</span>
                      <span>20</span>
                      <span>0</span>
                    </div>
                  </div>
                  <div
                    className={`mt-2 text-xs text-center ${
                      isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                    }`}
                  >
                    <span className="inline-flex items-center">
                      <ArrowUpRight className="h-3 w-3 mr-1 text-red-500" />
                      {Math.floor(Math.random() * 15) + 10}% increase from previous period
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="threats" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                      Attack Types
                    </CardTitle>
                  </div>
                  <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                    Distribution of detected attack types
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] relative">
                    <div className="absolute inset-0 flex items-end">
                      {chartData.attackTypes.map((attack, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center justify-end h-full px-1">
                          <div
                            className={`w-full rounded-t-sm transition-all duration-500 relative group ${
                              isUnderAttack && flashCount % 2 === 0
                                ? "bg-gradient-to-t from-red-800 to-red-600"
                                : "bg-gradient-to-t from-red-600 to-red-400"
                            }`}
                            style={{ height: `${(attack.value / 70) * 100}%` }}
                          >
                            <div className="absolute opacity-0 group-hover:opacity-100 bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded px-2 py-1 pointer-events-none transition-opacity">
                              {attack.value} attacks
                            </div>
                          </div>
                          <div
                            className={`text-xs mt-2 text-center ${
                              isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                            }`}
                          >
                            {attack.name}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div
                      className={`absolute left-0 top-0 bottom-0 flex flex-col justify-between text-xs ${
                        isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                      }`}
                    >
                      <span>70</span>
                      <span>50</span>
                      <span>30</span>
                      <span>10</span>
                      <span>0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Globe className="h-5 w-5 text-blue-500" />
                    <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                      Top Attack Sources
                    </CardTitle>
                  </div>
                  <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                    IP addresses with most connection attempts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Array.from({ length: 5 }).map((_, i) => {
                      const attempts = Math.floor(Math.random() * 100) + 20
                      return (
                        <div key={i} className="space-y-1">
                          <div className="flex items-center justify-between">
                            <div className={`font-mono ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}>
                              192.168.1.{Math.floor(Math.random() * 255)}
                            </div>
                            <div className="flex items-center gap-2">
                              <div
                                className={`font-medium ${isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}`}
                              >
                                {attempts}
                              </div>
                              <div
                                className={`text-xs ${
                                  isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                                }`}
                              >
                                attempts
                              </div>
                            </div>
                          </div>
                          <Progress value={(attempts / 120) * 100} className="h-2" />
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" size="sm" className="w-full bg-transparent" asChild>
                    <Link href="/logs">View All Sources</Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-6">
            <Card className={isUnderAttack && flashCount % 2 === 0 ? "bg-red-900 border-red-700" : ""}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle className={isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""}>
                    Recent Security Alerts
                  </CardTitle>
                </div>
                <CardDescription className={isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : ""}>
                  Latest security events requiring attention
                </CardDescription>
              </CardHeader>
              <CardContent>
                {recentAlerts.length > 0 ? (
                  <div className="space-y-4">
                    {recentAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`p-4 rounded-lg border ${
                          isUnderAttack && flashCount % 2 === 0
                            ? "bg-red-800 border-red-600"
                            : "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                            <p
                              className={`font-medium ${
                                isUnderAttack && flashCount % 2 === 0
                                  ? "text-white"
                                  : "text-amber-800 dark:text-amber-300"
                              }`}
                            >
                              {alert.type}
                            </p>
                          </div>
                          <Badge variant="outline" className="text-xs font-normal">
                            {alert.time.toLocaleTimeString()}
                          </Badge>
                        </div>
                        <p
                          className={`text-sm ${
                            isUnderAttack && flashCount % 2 === 0
                              ? "text-gray-300"
                              : "text-amber-700 dark:text-amber-400"
                          }`}
                        >
                          Source IP: <span className="font-mono">{alert.ip}</span>
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <Shield className="h-12 w-12 text-muted-foreground/50 mb-4" />
                    <h3
                      className={`text-lg font-medium mb-1 ${
                        isUnderAttack && flashCount % 2 === 0 ? "text-white" : ""
                      }`}
                    >
                      No Recent Alerts
                    </h3>
                    <p
                      className={`text-sm ${
                        isUnderAttack && flashCount % 2 === 0 ? "text-gray-300" : "text-muted-foreground"
                      }`}
                    >
                      No security alerts have been detected in the last 24 hours.
                    </p>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm" className="w-full bg-transparent" asChild>
                  <Link href="/logs">View All Alerts</Link>
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <style jsx>{`
        @keyframes scan {
          0% {
            top: 10%;
            opacity: 0;
          }
          50% {
            opacity: 1;
          }
          100% {
            top: 90%;
            opacity: 0;
          }
        }
      `}</style>
    </div>
  )
}
