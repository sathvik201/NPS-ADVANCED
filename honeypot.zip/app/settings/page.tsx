"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { AlertTriangle, Bell, Lock, Shield, User } from "lucide-react"

export default function SettingsPage() {
  const { user, hasRole } = useAuth()
  const { toast } = useToast()
  const [emailSettings, setEmailSettings] = useState({
    securityAlerts: true,
    systemUpdates: true,
    loginAttempts: true,
    weeklyReports: false,
  })

  const [notificationSettings, setNotificationSettings] = useState({
    browserNotifications: true,
    soundAlerts: true,
    criticalOnly: false,
  })

  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your settings have been updated successfully.",
    })
  }

  // Redirect if not admin
  if (!hasRole("admin")) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
          <h1 className="text-2xl font-bold mb-2">Access Restricted</h1>
          <p className="text-muted-foreground mb-6">You need administrator privileges to access this page.</p>
          <Button asChild>
            <a href="/dashboard">Return to Dashboard</a>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">System Settings</h1>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid grid-cols-4 w-full max-w-2xl">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-emerald-500" />
                  <CardTitle>General Settings</CardTitle>
                </div>
                <CardDescription>Configure basic system settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="system-name">System Name</Label>
                  <Input id="system-name" defaultValue="SecureHoney" />
                  <p className="text-sm text-muted-foreground">The name of your honeypot system</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="admin-email">Administrator Email</Label>
                  <Input id="admin-email" defaultValue={user?.email || "admin@securityhoney.com"} />
                  <p className="text-sm text-muted-foreground">Email address for system notifications</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="log-retention">Log Retention Period</Label>
                  <Select defaultValue="30">
                    <SelectTrigger id="log-retention">
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="14">14 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">
                    How long to keep security logs before automatic deletion
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-update" className="text-base">
                        Automatic Updates
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically update system components when available
                      </p>
                    </div>
                    <Switch id="auto-update" defaultChecked />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveSettings}>Save Settings</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-amber-500" />
                  <CardTitle>Notification Settings</CardTitle>
                </div>
                <CardDescription>Configure how and when you receive alerts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Email Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="security-alerts" className="text-base">
                          Security Alerts
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Receive email notifications for security incidents
                        </p>
                      </div>
                      <Switch
                        id="security-alerts"
                        checked={emailSettings.securityAlerts}
                        onCheckedChange={(checked) =>
                          setEmailSettings((prev) => ({ ...prev, securityAlerts: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="system-updates" className="text-base">
                          System Updates
                        </Label>
                        <p className="text-sm text-muted-foreground">Receive notifications about system updates</p>
                      </div>
                      <Switch
                        id="system-updates"
                        checked={emailSettings.systemUpdates}
                        onCheckedChange={(checked) => setEmailSettings((prev) => ({ ...prev, systemUpdates: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="login-attempts" className="text-base">
                          Login Attempts
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Receive notifications about failed login attempts
                        </p>
                      </div>
                      <Switch
                        id="login-attempts"
                        checked={emailSettings.loginAttempts}
                        onCheckedChange={(checked) => setEmailSettings((prev) => ({ ...prev, loginAttempts: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="weekly-reports" className="text-base">
                          Weekly Reports
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Receive weekly summary reports of system activity
                        </p>
                      </div>
                      <Switch
                        id="weekly-reports"
                        checked={emailSettings.weeklyReports}
                        onCheckedChange={(checked) => setEmailSettings((prev) => ({ ...prev, weeklyReports: checked }))}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Browser Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="browser-notifications" className="text-base">
                          Enable Notifications
                        </Label>
                        <p className="text-sm text-muted-foreground">Show browser notifications for security events</p>
                      </div>
                      <Switch
                        id="browser-notifications"
                        checked={notificationSettings.browserNotifications}
                        onCheckedChange={(checked) =>
                          setNotificationSettings((prev) => ({ ...prev, browserNotifications: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="sound-alerts" className="text-base">
                          Sound Alerts
                        </Label>
                        <p className="text-sm text-muted-foreground">Play sound when critical alerts are received</p>
                      </div>
                      <Switch
                        id="sound-alerts"
                        checked={notificationSettings.soundAlerts}
                        onCheckedChange={(checked) =>
                          setNotificationSettings((prev) => ({ ...prev, soundAlerts: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="critical-only" className="text-base">
                          Critical Alerts Only
                        </Label>
                        <p className="text-sm text-muted-foreground">Only notify for high severity security events</p>
                      </div>
                      <Switch
                        id="critical-only"
                        checked={notificationSettings.criticalOnly}
                        onCheckedChange={(checked) =>
                          setNotificationSettings((prev) => ({ ...prev, criticalOnly: checked }))
                        }
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveSettings}>Save Notification Settings</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-blue-500" />
                  <CardTitle>Security Settings</CardTitle>
                </div>
                <CardDescription>Configure system security options</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                  <Input id="session-timeout" type="number" defaultValue="30" />
                  <p className="text-sm text-muted-foreground">
                    Automatically log out inactive users after this period
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password-policy">Password Policy</Label>
                  <Select defaultValue="strong">
                    <SelectTrigger id="password-policy">
                      <SelectValue placeholder="Select policy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic (8+ characters)</SelectItem>
                      <SelectItem value="medium">Medium (8+ chars, mixed case)</SelectItem>
                      <SelectItem value="strong">Strong (8+ chars, mixed case, numbers)</SelectItem>
                      <SelectItem value="very-strong">Very Strong (12+ chars, mixed case, numbers, symbols)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">Password requirements for user accounts</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="two-factor" className="text-base">
                        Two-Factor Authentication
                      </Label>
                      <p className="text-sm text-muted-foreground">Require two-factor authentication for all users</p>
                    </div>
                    <Switch id="two-factor" defaultChecked />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="ip-restriction" className="text-base">
                        IP Restriction
                      </Label>
                      <p className="text-sm text-muted-foreground">Restrict access to specific IP addresses</p>
                    </div>
                    <Switch id="ip-restriction" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="allowed-ips">Allowed IP Addresses</Label>
                  <Input id="allowed-ips" placeholder="e.g. 192.168.1.1, 10.0.0.0/24" />
                  <p className="text-sm text-muted-foreground">Comma-separated list of IP addresses or CIDR ranges</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveSettings}>Save Security Settings</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-purple-500" />
                  <CardTitle>User Management</CardTitle>
                </div>
                <CardDescription>Manage system users and permissions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/50">
                          <th className="h-10 px-4 text-left font-medium">User</th>
                          <th className="h-10 px-4 text-left font-medium">Email</th>
                          <th className="h-10 px-4 text-left font-medium">Role</th>
                          <th className="h-10 px-4 text-left font-medium">Last Active</th>
                          <th className="h-10 px-4 text-left font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="p-4">Admin User</td>
                          <td className="p-4">admin@securityhoney.com</td>
                          <td className="p-4">Administrator</td>
                          <td className="p-4">Just now</td>
                          <td className="p-4">
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                          </td>
                        </tr>
                        <tr className="border-b">
                          <td className="p-4">Regular User</td>
                          <td className="p-4">user@securityhoney.com</td>
                          <td className="p-4">User</td>
                          <td className="p-4">2 hours ago</td>
                          <td className="p-4">
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                          </td>
                        </tr>
                        <tr>
                          <td className="p-4">Security Analyst</td>
                          <td className="p-4">analyst@securityhoney.com</td>
                          <td className="p-4">Analyst</td>
                          <td className="p-4">1 day ago</td>
                          <td className="p-4">
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <Button>Add New User</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
