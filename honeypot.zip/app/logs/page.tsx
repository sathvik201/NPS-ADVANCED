"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, ArrowUpDown, Download, Filter, RefreshCw, Search, Activity } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Function to generate random logs
const generateRandomLogs = (count = 20) => {
  const actions = [
    "Connection attempt",
    "Login attempt",
    "Login failed",
    "Port scan detected",
    "Brute force attack",
    "SQL injection attempt",
    "XSS attempt",
    "File inclusion attempt",
    "Command injection",
    "Information disclosure attempt",
  ]

  const services = ["SSH", "FTP", "HTTP", "SMTP", "Database", "Honeypot", "Telnet", "RDP"]
  const ports = [21, 22, 23, 25, 80, 443, 3306, 3389, 8080, 8443]

  const logs = []
  const now = new Date()

  for (let i = 0; i < count; i++) {
    const randomTime = new Date(now.getTime() - Math.floor(Math.random() * 86400000)) // Random time in the last 24 hours
    const randomAction = actions[Math.floor(Math.random() * actions.length)]
    const randomService = services[Math.floor(Math.random() * services.length)]
    const randomPort = ports[Math.floor(Math.random() * ports.length)]
    const randomIP = `192.168.1.${Math.floor(Math.random() * 255)}`

    logs.push({
      id: i + 1,
      timestamp: randomTime.toISOString(),
      ip: randomIP,
      action: randomAction,
      service: randomService,
      port: randomPort,
      severity:
        randomAction.includes("attack") || randomAction.includes("injection")
          ? "high"
          : randomAction.includes("failed") || randomAction.includes("scan")
            ? "medium"
            : "low",
    })
  }

  // Sort by timestamp, newest first
  return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
}

export default function SecurityLogs() {
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [severityFilter, setSeverityFilter] = useState("all")

  const refreshLogs = () => {
    setLoading(true)
    // Generate new random logs
    setTimeout(() => {
      setLogs(generateRandomLogs())
      setLoading(false)
    }, 500)
  }

  useEffect(() => {
    refreshLogs()
  }, [])

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleString()
  }

  const getSeverityBadge = (severity) => {
    switch (severity) {
      case "high":
        return <Badge variant="destructive">High</Badge>
      case "medium":
        return (
          <Badge variant="warning" className="bg-amber-500 hover:bg-amber-600">
            Medium
          </Badge>
        )
      case "low":
        return <Badge variant="outline">Low</Badge>
      default:
        return <Badge variant="outline">Info</Badge>
    }
  }

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      searchTerm === "" ||
      log.ip.includes(searchTerm) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.service.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesSeverity = severityFilter === "all" || log.severity === severityFilter

    return matchesSearch && matchesSeverity
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-2 mb-8">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Security Logs</h1>
      </div>

      <Card className="mb-8">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>System Security Logs</CardTitle>
              <CardDescription>View all security-related events including honeypot activity</CardDescription>
            </div>
            <Button onClick={refreshLogs} variant="outline" className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Refresh Logs
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-[180px]">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <SelectValue placeholder="Filter by severity" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Add a threat trends visualization to the logs page */}
          {/* Add this after the search/filter controls but before the table */}
          <div className="mb-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-amber-500" />
                  <CardTitle>Threat Activity Timeline</CardTitle>
                </div>
                <CardDescription>Visual representation of security events over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[180px]">
                  <div className="relative h-full">
                    <div className="absolute inset-0 flex items-end">
                      {Array.from({ length: 48 }).map((_, i) => {
                        const height = Math.floor(Math.random() * 70) + 5
                        const isCritical = Math.random() > 0.85
                        return (
                          <div
                            key={i}
                            className={`flex-1 ${
                              isCritical ? "bg-red-500" : "bg-amber-500/60 dark:bg-amber-500/40"
                            } rounded-t-sm mx-[1px] transition-all duration-300`}
                            style={{
                              height: `${height}%`,
                            }}
                          ></div>
                        )
                      })}
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-muted-foreground px-1">
                      <span>24h ago</span>
                      <span>18h ago</span>
                      <span>12h ago</span>
                      <span>6h ago</span>
                      <span>Now</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-amber-500/60 rounded-sm"></div>
                    <span>Standard Events</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-red-500 rounded-sm"></div>
                    <span>Critical Events</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Peak activity: {new Date(Date.now() - Math.floor(Math.random() * 86400000)).toLocaleTimeString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="flex flex-col items-center">
                <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Loading logs...</p>
              </div>
            </div>
          ) : (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">
                        <div className="flex items-center gap-1">
                          Timestamp
                          <ArrowUpDown className="h-3 w-3" />
                        </div>
                      </TableHead>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Service</TableHead>
                      <TableHead>Port</TableHead>
                      <TableHead>Severity</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.length > 0 ? (
                      filteredLogs.map((log) => (
                        <TableRow key={log.id} className="group hover:bg-muted/50">
                          <TableCell className="font-mono text-xs">{formatDate(log.timestamp)}</TableCell>
                          <TableCell className="font-mono">{log.ip}</TableCell>
                          <TableCell>{log.action}</TableCell>
                          <TableCell>{log.service}</TableCell>
                          <TableCell>{log.port}</TableCell>
                          <TableCell>{getSeverityBadge(log.severity)}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="h-24 text-center">
                          No logs found matching your criteria.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
              <div className="text-xs text-muted-foreground mt-4 text-right">
                Showing {filteredLogs.length} of {logs.length} logs
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
