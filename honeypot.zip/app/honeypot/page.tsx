"use client"

import { useState, useEffect } from "react"
import { AlertTriangle, ArrowLeft, Clock, Globe, Info, Server, Shield, Wifi, Activity } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function HoneypotConfig() {
  const [isActive, setIsActive] = useState(false)
  const [port, setPort] = useState("8080")
  const [logAttempts, setLogAttempts] = useState(0)
  const [cpuUsage, setCpuUsage] = useState(12)
  const [memoryUsage, setMemoryUsage] = useState(28)
  const [uptime, setUptime] = useState("2d 7h 15m")
  const [honeypotType, setHoneypotType] = useState("web-server")

  // Simulate honeypot activity when active
  useEffect(() => {
    if (!isActive) return

    const interval = setInterval(() => {
      // Simulate random connection attempts when honeypot is active
      if (Math.random() > 0.6) {
        setLogAttempts((prev) => prev + 1)
      }

      // Simulate changing resource usage
      setCpuUsage(Math.floor(Math.random() * 30) + 10)
      setMemoryUsage(Math.floor(Math.random() * 40) + 20)
    }, 3000)

    return () => clearInterval(interval)
  }, [isActive])

  const handleActivate = () => {
    setIsActive(!isActive)
    if (!isActive) {
      // Log activation to the server
      logHoneypotAction("activated")
    } else {
      // Log deactivation to the server
      logHoneypotAction("deactivated")
    }
  }

  const logHoneypotAction = async (action) => {
    try {
      await fetch("/api/honeypot/log", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action,
          timestamp: new Date().toISOString(),
          port,
          type: honeypotType,
        }),
      })
    } catch (error) {
      console.error("Failed to log honeypot action:", error)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-2 mb-8">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Honeypot Configuration</h1>
        <Badge variant={isActive ? "success" : "secondary"} className="ml-2">
          {isActive ? "Active" : "Inactive"}
        </Badge>
      </div>

      <Tabs defaultValue="settings" className="space-y-6">
        <TabsList className="grid grid-cols-3 w-full max-w-md">
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-emerald-500" />
                  <CardTitle>Honeypot Settings</CardTitle>
                </div>
                <CardDescription>Configure your honeypot to detect unauthorized access attempts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <div className="space-y-0.5">
                      <Label htmlFor="honeypot-status" className="text-base">
                        Honeypot Status
                      </Label>
                      <p className="text-sm text-muted-foreground">Activate or deactivate the honeypot service</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="honeypot-status"
                        checked={isActive}
                        onCheckedChange={handleActivate}
                        className="data-[state=checked]:bg-emerald-500"
                      />
                      <span className={isActive ? "text-emerald-500 font-medium" : "text-muted-foreground"}>
                        {isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="honeypot-type">Honeypot Type</Label>
                      <Select value={honeypotType} onValueChange={setHoneypotType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="web-server">Web Server</SelectItem>
                          <SelectItem value="ssh">SSH Server</SelectItem>
                          <SelectItem value="ftp">FTP Server</SelectItem>
                          <SelectItem value="database">Database Server</SelectItem>
                          <SelectItem value="iot">IoT Device</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-sm text-muted-foreground">The type of service the honeypot will emulate</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="port">Listening Port</Label>
                      <Input id="port" value={port} onChange={(e) => setPort(e.target.value)} placeholder="8080" />
                      <p className="text-sm text-muted-foreground">
                        The port on which the honeypot will listen for connections
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="logging-level">Logging Level</Label>
                    <Select defaultValue="detailed">
                      <SelectTrigger>
                        <SelectValue placeholder="Select logging level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="detailed">Detailed</SelectItem>
                        <SelectItem value="verbose">Verbose</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">Controls the amount of information captured in logs</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Reset to Defaults</Button>
                <Button
                  onClick={handleActivate}
                  variant={isActive ? "destructive" : "default"}
                  className={isActive ? "" : "bg-emerald-500 hover:bg-emerald-600"}
                >
                  {isActive ? "Deactivate Honeypot" : "Activate Honeypot"}
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-emerald-500" />
                  <CardTitle>Status</CardTitle>
                </div>
                <CardDescription>Current status and statistics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium flex items-center gap-2">
                      <Wifi className="w-4 h-4 text-muted-foreground" />
                      Status:
                    </span>
                    <Badge variant={isActive ? "success" : "outline"} className="font-medium">
                      {isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-medium flex items-center gap-2">
                      <Server className="w-4 h-4 text-muted-foreground" />
                      Type:
                    </span>
                    <span className="font-medium">
                      {honeypotType.replace("-", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-medium flex items-center gap-2">
                      <Globe className="w-4 h-4 text-muted-foreground" />
                      Port:
                    </span>
                    <span className="font-mono">{port}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-medium flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-muted-foreground" />
                      Attempts:
                    </span>
                    <span className="font-mono">{logAttempts}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-medium flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      Uptime:
                    </span>
                    <span>{isActive ? uptime : "—"}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href="/logs">View Detailed Logs</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-blue-500" />
                <CardTitle>Connection Attempts</CardTitle>
              </div>
              <CardDescription>Weekly honeypot activity monitoring</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                {isActive ? (
                  <div className="relative h-full">
                    <div className="absolute inset-0 flex items-end">
                      {Array.from({ length: 24 }).map((_, i) => (
                        <div
                          key={i}
                          className="flex-1 bg-blue-500/20 dark:bg-blue-500/10 rounded-t-sm mx-[1px] transition-all duration-500"
                          style={{
                            height: `${Math.max(5, Math.floor(Math.random() * (logAttempts > 0 ? 80 : 30)) + 5)}%`,
                          }}
                        ></div>
                      ))}
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-muted-foreground px-1">
                      <span>00:00</span>
                      <span>06:00</span>
                      <span>12:00</span>
                      <span>18:00</span>
                      <span>23:59</span>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center">
                    <Shield className="h-12 w-12 text-muted-foreground/30 mb-4" />
                    <p className="text-muted-foreground text-sm">Activate the honeypot to see connection data</p>
                  </div>
                )}
              </div>
              <div className="mt-4 flex items-center justify-between text-sm">
                <div>
                  <p className="font-medium">Total Attempts</p>
                  <p className="text-2xl font-bold">{logAttempts}</p>
                </div>
                <div>
                  <p className="font-medium">Peak Hour</p>
                  <p className="text-2xl font-bold">{isActive ? `${Math.floor(Math.random() * 24)}:00` : "—"}</p>
                </div>
                <div>
                  <p className="font-medium">Last Attempt</p>
                  <p className="text-2xl font-bold">{isActive ? `${Math.floor(Math.random() * 60)} min ago` : "—"}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-blue-500" />
                  <CardTitle>System Resources</CardTitle>
                </div>
                <CardDescription>Current resource utilization</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>CPU Usage</Label>
                      <span className="text-sm font-medium">{cpuUsage}%</span>
                    </div>
                    <Progress value={cpuUsage} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>Memory Usage</Label>
                      <span className="text-sm font-medium">{memoryUsage}%</span>
                    </div>
                    <Progress value={memoryUsage} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>Disk Usage</Label>
                      <span className="text-sm font-medium">42%</span>
                    </div>
                    <Progress value={42} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>Network Traffic</Label>
                      <span className="text-sm font-medium">1.2 MB/s</span>
                    </div>
                    <Progress value={35} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <CardTitle>Recent Alerts</CardTitle>
                </div>
                <CardDescription>Latest security events detected</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {isActive && logAttempts > 0 ? (
                    <>
                      <div className="p-3 rounded-lg border bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                          <p className="font-medium text-amber-800 dark:text-amber-300">Connection attempt detected</p>
                        </div>
                        <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                          IP: 192.168.1.{Math.floor(Math.random() * 255)} - {new Date().toLocaleTimeString()}
                        </p>
                      </div>

                      <div className="p-3 rounded-lg border bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                          <p className="font-medium text-red-800 dark:text-red-300">Brute force attempt</p>
                        </div>
                        <p className="text-sm text-red-700 dark:text-red-400 mt-1">
                          IP: 192.168.1.{Math.floor(Math.random() * 255)} -{" "}
                          {new Date(Date.now() - 120000).toLocaleTimeString()}
                        </p>
                      </div>

                      <div className="p-3 rounded-lg border bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                          <p className="font-medium text-amber-800 dark:text-amber-300">Port scan detected</p>
                        </div>
                        <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                          IP: 192.168.1.{Math.floor(Math.random() * 255)} -{" "}
                          {new Date(Date.now() - 300000).toLocaleTimeString()}
                        </p>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <Shield className="h-12 w-12 text-muted-foreground/50 mb-4" />
                      <h3 className="text-lg font-medium mb-1">No Recent Alerts</h3>
                      <p className="text-sm text-muted-foreground">
                        {isActive
                          ? "The honeypot is active but no suspicious activity has been detected yet."
                          : "Activate the honeypot to start monitoring for suspicious activity."}
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href="/logs">View All Alerts</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Server className="h-5 w-5 text-purple-500" />
                <CardTitle>Advanced Configuration</CardTitle>
              </div>
              <CardDescription>Fine-tune your honeypot settings for advanced scenarios</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="response-delay">Response Delay (ms)</Label>
                    <Input id="response-delay" type="number" defaultValue="200" />
                    <p className="text-sm text-muted-foreground">Simulated response time to appear more realistic</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="emulation-level">Emulation Level</Label>
                    <Select defaultValue="medium">
                      <SelectTrigger id="emulation-level">
                        <SelectValue placeholder="Select emulation level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low (Basic responses)</SelectItem>
                        <SelectItem value="medium">Medium (Standard emulation)</SelectItem>
                        <SelectItem value="high">High (Advanced interaction)</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">Level of service emulation and interaction</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-update" className="text-base">
                        Auto-Update Signatures
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically update threat signatures and emulation patterns
                      </p>
                    </div>
                    <Switch id="auto-update" defaultChecked />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="alert-notifications" className="text-base">
                        Alert Notifications
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Send email notifications for critical security events
                      </p>
                    </div>
                    <Switch id="alert-notifications" defaultChecked />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="data-collection" className="text-base">
                        Extended Data Collection
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Collect additional data about attack patterns and techniques
                      </p>
                    </div>
                    <Switch id="data-collection" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button>Save Advanced Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
