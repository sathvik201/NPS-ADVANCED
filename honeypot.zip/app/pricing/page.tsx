"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Check, CreditCard, Shield, Zap, Globe, Activity, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"

export default function PricingPage() {
  const [isYearly, setIsYearly] = useState(false)
  const { toast } = useToast()

  const plans = [
    {
      name: "Starter",
      description: "Perfect for small businesses and personal use",
      price: isYearly ? 29 : 39,
      yearlyPrice: 29,
      monthlyPrice: 39,
      features: [
        "Basic honeypot monitoring",
        "Up to 1,000 events/month",
        "Email alerts",
        "7-day data retention",
        "Basic threat detection",
        "Community support",
      ],
      popular: false,
      color: "blue",
    },
    {
      name: "Professional",
      description: "Advanced security for growing organizations",
      price: isYearly ? 79 : 99,
      yearlyPrice: 79,
      monthlyPrice: 99,
      features: [
        "Advanced honeypot types",
        "Up to 10,000 events/month",
        "Real-time alerts & notifications",
        "30-day data retention",
        "AI-powered threat analysis",
        "Global attack map",
        "API access",
        "Priority support",
      ],
      popular: true,
      color: "emerald",
    },
    {
      name: "Enterprise",
      description: "Complete security solution for large organizations",
      price: isYearly ? 199 : 249,
      yearlyPrice: 199,
      monthlyPrice: 249,
      features: [
        "Unlimited honeypot instances",
        "Unlimited events",
        "Custom integrations",
        "1-year data retention",
        "Advanced ML threat detection",
        "Custom threat intelligence",
        "Dedicated account manager",
        "24/7 phone support",
        "SLA guarantee",
      ],
      popular: false,
      color: "purple",
    },
  ]

  const handleSubscribe = (planName, price) => {
    toast({
      title: "Subscription Started",
      description: `Successfully subscribed to ${planName} plan for $${price}/month`,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-2 mb-8">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Pricing Plans</h1>
        </div>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Choose Your Security Level</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Protect your infrastructure with our advanced honeypot solutions
          </p>

          <div className="flex items-center justify-center gap-4 mb-8">
            <span className={`text-sm ${!isYearly ? "font-semibold" : "text-muted-foreground"}`}>Monthly</span>
            <Switch checked={isYearly} onCheckedChange={setIsYearly} className="data-[state=checked]:bg-emerald-500" />
            <span className={`text-sm ${isYearly ? "font-semibold" : "text-muted-foreground"}`}>Yearly</span>
            <Badge variant="outline" className="ml-2">
              Save 25%
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => (
            <Card
              key={plan.name}
              className={`relative ${plan.popular ? "border-2 border-emerald-500 shadow-lg scale-105" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-emerald-500 hover:bg-emerald-600">Most Popular</Badge>
                </div>
              )}

              <CardHeader className="text-center">
                <div
                  className={`w-12 h-12 mx-auto mb-4 rounded-full bg-${plan.color}-100 dark:bg-${plan.color}-900 flex items-center justify-center`}
                >
                  {plan.name === "Starter" && (
                    <Shield className={`h-6 w-6 text-${plan.color}-600 dark:text-${plan.color}-400`} />
                  )}
                  {plan.name === "Professional" && (
                    <Zap className={`h-6 w-6 text-${plan.color}-600 dark:text-${plan.color}-400`} />
                  )}
                  {plan.name === "Enterprise" && (
                    <Globe className={`h-6 w-6 text-${plan.color}-600 dark:text-${plan.color}-400`} />
                  )}
                </div>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4">
                  <div className="text-4xl font-bold">
                    ${plan.price}
                    <span className="text-lg font-normal text-muted-foreground">/{isYearly ? "year" : "month"}</span>
                  </div>
                  {isYearly && (
                    <div className="text-sm text-muted-foreground">${plan.monthlyPrice}/month billed annually</div>
                  )}
                </div>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button
                  className={`w-full ${plan.popular ? "bg-emerald-500 hover:bg-emerald-600" : ""}`}
                  variant={plan.popular ? "default" : "outline"}
                  onClick={() => handleSubscribe(plan.name, plan.price)}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Subscribe to {plan.name}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card>
            <CardHeader className="text-center">
              <Activity className="h-8 w-8 mx-auto mb-2 text-blue-500" />
              <CardTitle className="text-lg">Real-time Monitoring</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center">
                Monitor attacks as they happen with live dashboards and instant notifications
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <Globe className="h-8 w-8 mx-auto mb-2 text-emerald-500" />
              <CardTitle className="text-lg">Global Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center">
                Track threats from around the world with our global attack visualization
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <AlertTriangle className="h-8 w-8 mx-auto mb-2 text-amber-500" />
              <CardTitle className="text-lg">Smart Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center">
                AI-powered threat detection with customizable alert thresholds
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <Shield className="h-8 w-8 mx-auto mb-2 text-purple-500" />
              <CardTitle className="text-lg">Advanced Security</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center">
                Multiple honeypot types and advanced deception techniques
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-gradient-to-r from-emerald-50 to-blue-50 dark:from-emerald-950/20 dark:to-blue-950/20 border-emerald-200 dark:border-emerald-800">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Need a Custom Solution?</h3>
            <p className="text-muted-foreground mb-6">
              Contact our sales team for enterprise-grade security solutions tailored to your specific needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="outline">
                Contact Sales
              </Button>
              <Button size="lg">Schedule Demo</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
